package net.fabricmc.example.waypoints;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static net.fabricmc.example.waypoints.WaypointStore.ACTIVE;

public final class WaypointCommands {
    private WaypointCommands() {}

    public static void register(CommandDispatcher<class_2168> d) {
        d.register(class_2170.method_9247("wp")
            .then(class_2170.method_9247("set")
                .then(class_2170.method_9244("name", StringArgumentType.word())
                    .executes(ctx -> {
                        class_3222 p = ctx.getSource().method_9207();
                        String dim = p.method_51469().method_27983().method_29177().toString();
                        var pos = p.method_24515();
                        String name = StringArgumentType.getString(ctx, "name");
                        var wp = new WaypointStore.Waypoint(pos.method_10263(), pos.method_10264(), pos.method_10260(), dim, name);
                        WaypointStore.set(p.method_5667(), name, wp);
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§aSaved waypoint §e" + name + " §7@ " + pos.method_10263()+","+pos.method_10264()+","+pos.method_10260()+" §7in §e" + dim), false);
                        return 1;
                    })
                )
            )
            .then(class_2170.method_9247("goto")
                .then(class_2170.method_9244("name", StringArgumentType.word())
                    .executes(ctx -> {
                        class_3222 p = ctx.getSource().method_9207();
                        String name = StringArgumentType.getString(ctx, "name");
                        var wp = WaypointStore.find(p.method_5667(), name);
                        if (wp == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("No waypoint named '" + name + "'."));
                            return 0;
                        }
                        ACTIVE.put(p.method_5667(), wp);
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§aTracking §e" + name + " §7(§f" + wp.x()+","+wp.y()+","+wp.z()+"§7)"), false);
                        return 1;
                    })
                )
            )
            .then(class_2170.method_9247("list")
                .executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    var map = WaypointStore.get(p.method_5667());
                    if (map.isEmpty()) {
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§7No waypoints yet. Use §e/wp set <name>"), false);
                        return 1;
                    }
                    ctx.getSource().method_9226(() -> class_2561.method_43470("§aWaypoints:"), false);
                    map.forEach((n, wp) ->
                        ctx.getSource().method_9226(() ->
                            class_2561.method_43470(" - §e" + n + "§7 @ (" + wp.x()+","+wp.y()+","+wp.z()+") §7" + wp.dimension()), false)
                    );
                    return 1;
                })
            )
            .then(class_2170.method_9247("share")
                .then(class_2170.method_9244("name", StringArgumentType.word())
                    .executes(ctx -> {
                        class_3222 p = ctx.getSource().method_9207();
                        String name = StringArgumentType.getString(ctx, "name");
                        var wp = WaypointStore.find(p.method_5667(), name);
                        if (wp == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("No waypoint named '" + name + "'."));
                            return 0;
                        }

                        String cmd = String.format("/wp track_from %d %d %d %s \"%s\"",
                                wp.x(), wp.y(), wp.z(), wp.dimension(), name);

                        String json = String.format(
                            "{\"text\":\"[Track '%s' at (%d, %d, %d)]\",\"color\":\"yellow\"," +
                            "\"clickEvent\":{\"action\":\"run_command\",\"value\":\"%s\"}," +
                            "\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"Click to track this waypoint\",\"color\":\"gray\"}}}",
                            name, wp.x(), wp.y(), wp.z(), cmd.replace("\"","\\\"")
                        );

                        ctx.getSource().method_9211().method_3734()
                            .method_44252(ctx.getSource(), "tellraw @a " + json);

                        // NOTE: sendFeedback expects Supplier<Text> in your mappings:
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§aShared §e" + name), false);
                        return 1;
                    })
                )
            )


            .then(class_2170.method_9247("track_from")
                .then(class_2170.method_9244("x", IntegerArgumentType.integer())
                    .then(class_2170.method_9244("y", IntegerArgumentType.integer())
                        .then(class_2170.method_9244("z", IntegerArgumentType.integer())
                            .then(class_2170.method_9244("dimension", StringArgumentType.string())
                                .then(class_2170.method_9244("label", StringArgumentType.greedyString())
                                    .executes(ctx -> {
                                        class_3222 p = ctx.getSource().method_9207();
                                        int x = IntegerArgumentType.getInteger(ctx, "x");
                                        int y = IntegerArgumentType.getInteger(ctx, "y");
                                        int z = IntegerArgumentType.getInteger(ctx, "z");
                                        String dim = StringArgumentType.getString(ctx, "dimension");
                                        String label = StringArgumentType.getString(ctx, "label").replace("\"", "");
                                        var wp = new WaypointStore.Waypoint(x, y, z, dim, label);
                                        ACTIVE.put(p.method_5667(), wp);
                                        ctx.getSource().method_9226(() -> class_2561.method_43470("§aTracking §e" + label + " §7(" + x+","+y+","+z+")"), false);
                                        return 1;
                                    })
                                )
                            )
                        )
                    )
                )
            )
            .then(class_2170.method_9247("clear")
                .executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    ACTIVE.remove(p.method_5667());
                    ctx.getSource().method_9226(() -> class_2561.method_43470("§7Tracking cleared."), false);
                    return 1;
                })
            )
        );
    }
}
