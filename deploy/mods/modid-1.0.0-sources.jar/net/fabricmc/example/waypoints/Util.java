package net.fabricmc.example.waypoints;

import net.minecraft.class_2338;
import net.minecraft.class_3222;

public final class Util {
    private Util() {}

    public static int distanceMeters(class_2338 a, class_2338 b) {
        int dx = a.method_10263() - b.method_10263();
        int dz = a.method_10260() - b.method_10260();
        return (int) Math.round(Math.sqrt(dx * dx + dz * dz));
    }

    public static double bearingDeg(class_3222 p, class_2338 target) {
        double dx = target.method_10263() + 0.5 - p.method_23317();
        double dz = target.method_10260() + 0.5 - p.method_23321();
        double angleRad = Math.atan2(-dx, dz); // 0 = North
        double angleDeg = Math.toDegrees(angleRad);
        angleDeg = (angleDeg + 360.0) % 360.0;

        double playerYaw = (p.method_36454() % 360.0 + 360.0) % 360.0;
        double rel = angleDeg - ((-playerYaw + 180.0 + 360.0) % 360.0);
        rel = (rel + 360.0) % 360.0;
        return rel;
    }

    public static String dirArrow(double deg) {
        int sector = (int)Math.floor(((deg + 22.5) % 360) / 45.0);
        return switch (sector) {
            case 0 -> "↑";
            case 1 -> "↗";
            case 2 -> "→";
            case 3 -> "↘";
            case 4 -> "↓";
            case 5 -> "↙";
            case 6 -> "←";
            default -> "↖";
        };
    }




}
