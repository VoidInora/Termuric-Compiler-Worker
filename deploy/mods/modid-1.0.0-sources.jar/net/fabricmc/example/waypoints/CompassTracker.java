package net.fabricmc.example.waypoints;

import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

import static net.fabricmc.example.waypoints.Util.bearingDeg;
import static net.fabricmc.example.waypoints.Util.dirArrow;
import static net.fabricmc.example.waypoints.Util.distanceMeters;

public final class CompassTracker {
    private static MinecraftServer SERVER;
    private static int tickCounter = 0;

    private CompassTracker() {}

    public static void init(MinecraftServer server) {
        SERVER = server;
    }

    public static void onServerTick() {
        if (SERVER == null) return;
        tickCounter++;
        if (tickCounter % 20 != 0) return; // every ~1s

        for (class_3222 p : SERVER.method_3760().method_14571()) {
            var wp = WaypointStore.ACTIVE.get(p.method_5667());
            if (wp == null) continue;

            String playerDim = p.method_51469().method_27983().method_29177().toString();
            if (!playerDim.equals(wp.dimension())) {
                p.method_7353(class_2561.method_43470("§7[wp] §fTarget in different dimension: §e" + wp.dimension()), true);
                continue;
            }

            int dist = distanceMeters(p.method_24515(), wp.pos());
            double bearing = bearingDeg(p, wp.pos());
            String arrow = dirArrow(bearing);
            String name = (wp.name() == null || wp.name().isEmpty()) ? "target" : wp.name();

            p.method_7353(class_2561.method_43470(arrow + " " + dist + "m · \"" + name + "\""), true);
        }
    }
}
